<?php session_start();
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("exam",$con)or die("could not connect");
$e="select * from tbl_registration";
$g=mysql_query($e);
$r=mysql_num_rows($g); if($r>0)
{
?>
<center><h2><u>VIEW USER</u></h2></center>
<form name="frmview" method="post"action="">
<center>
<table width="500" border="1"cellpadding="10"cellspacing="5">
<tr>
<th>registernumber</th><th>name</th><th>dob</th><th>gender</th><th>course
</t h><th>date</th><th>phone</th><th>username</th><th>password</th>
</tr>
<?php while($row=mysql_fetch_array($g))
{
?>
<tr>
<td><?php  echo $row[0];?></td>
<td><?php  echo $row[1];?></td>
<td><?php  echo $row[2];?></td>
<td><?php  echo $row[3];?></td>
<td><?php  echo $row[4];?></td>
<td><?php  echo $row[5];?></td>
<td><?php  echo $row[6];?></td>
<td><?php  echo $row[7];?></td>
<td><?php  echo $row[8];?></td>
</tr>
<?php
}
}
?>
</table>
</center>
</form>
