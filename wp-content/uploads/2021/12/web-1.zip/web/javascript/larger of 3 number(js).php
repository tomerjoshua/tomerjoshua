<html>
	<head>
		<script> 			function largestnum() 	
		{ 		
		var num1, num2, num3; 				num1 = Number(document.getElementById("N").value); 		
		num2 = Number(document.getElementById("M").value); 				num3 = Number(document.getElementById("O").value); 				if(num1>num2 && num1>num3) 		
		{ 					window.alert(num1+"-is greatest"); 	
			} 			
	else if(num2>num1 && num2>num3) 			
	{ 					window.alert(num2+"-is greatst"); 			
	} 			
	else if(num3>num1 && num3>num1) 			
	{ 					window.alert(num3+"is greatest"); 			
	} 	
		}
		</script> 	
</head> 	
<body>
		<h1>Check largest number </h1> 		<br>
		Enter number 1: <input type="text" id="N"></input><br> 	
	Enter number 2: <input type="text" id="M"></input><br> 	
	Enter number 3: <input type="text" id="O"></input><br>
<button onclick="largestnum()">submit</button>
 	</body>
 </html>