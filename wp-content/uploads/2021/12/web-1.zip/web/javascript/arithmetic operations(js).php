<html>
 <head> <title>Javascript arithmetic operations program</title>
 </head>
<body> <h1>Performing Arithmetic Operations </h1> <script>
 var a = 12, b = 3; var addition, subtraction, multiplication, division, modulus;
addition = a + b;
 subtraction = a - b;  multiplication = a * b;  division = a / b;
 modulus = a % b;  document.write("Addition of " + a +' and ' + b +" is = " + addition + "<br />"); document.write("Subtraction of " + a +' and ' + b +" is = " + subtraction + "<br />"); document.write("Multiplication of " + a +' and ' + b +" is = " + multiplication + "<br />"); document.write("Division of " + a +' and ' + b +" is = " + division + "<br />"); document.write("Modulus of " + a +' and ' + b +" is = " + modulus + "<br />");
</script>
</body>
</html>