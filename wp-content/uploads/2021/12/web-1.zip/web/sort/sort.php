<?php
echo "<b>NUMERICAL ARRAY SORT</b>";
echo "<br>";
echo "<br>";
$ar=array(25,12,90,34,23);
$c=count($ar); 
sort($ar);
echo "<u>Sort array in ascending order (sort() function)</u>"; 
echo "<br>";
for($i=0;$i<$c;$i++)
{
echo $ar[$i]; 
echo "<br>";
}
rsort($ar); 
echo "<br>";
echo "<u>Sort array in descending order (rsort() function)</u><br>"; 
for($i=0;$i<$c;$i++)
{
echo $ar[$i]; 
echo "<br>";
}
echo "<br><b>ASSOCIATIVE ARRAY SORT </b><br>";
$ar1=array("Achu"=>22,"Bichu"=>26,"Appu"=>22); 
echo "<br><u>asort() function</u><br>";
echo "<br>"; 
asort($ar1);
foreach($ar1 as $a=>$b)
{
echo"key =".$a.",value=".$b; 
echo "<br>";

}
echo "<br>"; 
arsort($ar1); 
echo "<br>";
echo "<br><u>arsort()function</u><br>"; 
foreach($ar1 as $a=>$b)
{
echo "key=".$a.",value=".$b; 
echo "<br>";
}
ksort($ar1); 
echo "<br>";
echo "<br><u>ksort() function </u><br>";
foreach($ar1 as $a=>$b)
{
echo"key=".$a.",value=".$b; 
echo "<br>";
}
krsort($ar1); 
echo "<br>";
echo "<br><u>krsort() function</u></br>"; 
foreach($ar1 as $a=>$b)
{
    echo "key=".$a.",value=".$b; } echo "<br>";
    ?>
    