
<form name="frmregistration" method="post" action="regaction.php">
<center>
<table width="500" border="1" cellpadding="5" cellspacing="5">
<tr>
<th align="center"><u>REGISTERATION FORM</u></th>
</tr>
<tr>
<td align="center">Register Number</td>
<td align="center"><input type="text" name="txt1"></td>
</tr>
<tr>
<td align="center">Name</td>
<td align="center"><input type="text" name="txt2"></td>
</tr>
<tr>
<td align="center">Date of Birth</td>
<td align="center"><input type="text" name="txt7"></td>
</tr>
<td align="center">Gender</td>
<td align="center"><input type="radio" name="radio1" value="Male">Male
<input type="radio" name="radio1"value="Female">Female</td>
</tr>
<tr>
<td align="center">Course</td>
<td align="center"><select name="list1">
<option>Mca</option>
<option>Bca</option>
<option>Bba</option>

</select>
</td>
</tr>
<tr>
<td align="center">date of admisssion</td>
<td align="center"><input type="text" name="txt3" value="<?php echo date("d/m/y");?>"></td>
</tr>
<tr>
<td align="center">Phone</td>
<td align="center"><input type="text" name="txt4">
</tr>
<tr>
<td align="center">Username</td>
<td align="center"><input type="text" name="txt5"></td>
</tr>
<tr>
<td align="center">Password</td>
<td align="center"><input type="text" name="txt6"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="btn1" value="Submit"></td>
<td align="center"><input type="reset" name="btn2" value="cancel"></td>
</tr>
</table>
</center>
</form>
