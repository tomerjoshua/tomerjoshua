<?php
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("exam",$con)or die("could not connect");
$r=$_POST['txt1'];
$n=$_POST['txt2'];
$dob=$_POST['txt7'];
$gen=$_POST["radio1"];
$c=$_POST['list1'];
$d=$_POST['txt3'];
$p=$_POST['txt4'];
$u=$_POST['txt5'];
$pas=$_POST['txt6']; 
if(isset($_POST['btn1']))
{
    $t1="insert into tbl_registration(regno,name,dob,gender,course,date,phone,username,password)values($r,'$n','$dob','$gen','$c','$d',$p,'$u','$pas')";
    $g=mysql_query($t1);
    echo "Registered successfully !!!";
    }
    ?>
    