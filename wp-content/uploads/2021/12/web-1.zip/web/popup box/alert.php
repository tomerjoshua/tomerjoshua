<html>
    <head>
        <script type="text/javascript">
            function fun()
            {
                alert(location.hostname);

            }
        </script>
    </head>
    <body>
        <p>Click the button to see the effect </p>
<form>
    <input type="button" value="cluck me" onclick="fun()"/>
</form>  
</body>
</html>