<html>
    <head>
        <script type="text/javascript">
        function fun()
            {
                prompt("this is a prompt box ","Hello World !!!!");
            }
        </script>
        <body>
            <p>
                Click the button to see the effect
            </p>
            <form>
                <input type="button" value="click" onclick="fun()"/>

            </form>
        </body>
    </head>
</html>