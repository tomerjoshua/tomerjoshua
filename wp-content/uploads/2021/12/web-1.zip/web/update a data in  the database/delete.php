<?php
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("exam",$con)or die("could not conncet to database");
$r=$_GET['id'];
$a="delete from tbl_registration where roll_no='$r'";
$q=mysql_query($a);
echo "<meta http-equiv=\"refresh\"content=\"0;URL=viewuser.php\">";
?> <?php
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("mca3",$con)or die("could not conncet to database");
$r=$_GET['id'];
$a="delete from tbl_registration where roll_no='$r'";
$q=mysql_query($a);
echo "<meta http-equiv=\"refresh\"content=\"0;URL=viewuser.php\">";
?>
