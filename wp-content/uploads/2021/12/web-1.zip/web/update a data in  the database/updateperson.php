<?php session_start();
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("exam",$con)or die("could not connect to database");


$e="select * from tbl_registration";
$g=mysql_query($e);
$r=mysql_num_rows($g); if($r>0)
{
?>
<h2><center><u>VIEW USER</u></center></h2>
<form name="frmsearch" method="post" action=""><center>
<table width="421" border="1" cellpadding="2" align="center">
<tr>
<th align=center>Roll No:</th><th align=center>Name:</th><th align=center>Age:</th><th align=center>Address:</th><th align=center>Phone:</th><th align=center>Email:</th><th align=center>
Username:</th><th align=center>Password:</th><th align=center>Update</th><th align=center>Delete</th>
</tr>
<?php while($row=mysql_fetch_array($g))
{
?>
<tr>
<td><?php echo $row[0];?></td>

<td><?php  echo $row[1];?></td>
<td><?php  echo $row[2];?></td>
<td><?php  echo $row[3];?></td>
<td><?php  echo $row[4];?></td>
<td><?php  echo $row[5];?></td>
<td><?php  echo $row[6];?></td>
<td><?php  echo $row[7];?></td>
<td><a href="update.php?id=<?php echo $row[0];?>">Update</a></td>
<td><a href="delete.php?id=<?php echo $row[0];?>">Delete</a>
</tr>


</tr>
<?php
}
}
else
{
echo "THE USER IS NOT FOUND";
}
?>
</table>
</center>
</form>
