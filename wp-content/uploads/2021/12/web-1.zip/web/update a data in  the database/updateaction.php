<?php
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("exam",$con)or die("could not conncet to database");
$r=$_POST['txt9'];
$na=$_POST['txt2'];
$age=$_POST['txt3'];
$add=$_POST['txt4'];
$ph=$_POST['txt5'];
$e=$_POST['txt6'];
$u=$_POST['txt7'];
$p=$_POST['txt8'];
$a="update tbl_registration set name='$na',age=$age,address='$add',phone=$ph,email='$e',username='$u',password='$p' where roll_no=$r";
echo $a;
$g=mysql_query($a);
echo "DETAILS UPDATED";
echo "<meta http-equiv=\"refresh\"content=\"0;URL=viewuser.php\">";
?>
