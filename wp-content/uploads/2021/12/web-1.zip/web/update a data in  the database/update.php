<?php
$con=mysql_connect("localhost","root","")or die("could not connect");
$db=mysql_select_db("exam",$con)or die("could not conncet to database");
$n=$_GET['id'];
$n="select * from tbl_registration where roll_no='$n'";
$g=mysql_query($n);
$r=mysql_num_rows($g);
if($r>0)
{
?>
<form name="frmupdate" method="post"action="updateaction.php">
<table width="708" border="1"cellpadding="10"cellspacing="1">
<tr>
<th>Roll NO</th>
<th>Name</th>
<th>Age</th>
<th>Address</th>
<th>Phone</th>
<th>Email</th>
<th>User Name</th>
<th>Password</th>
</tr>
<?php while($row=mysql_fetch_array($g))
{
?>
<tr>
<td>
<input type="hidden" name="txt9" value="<?php echo $row[0];?>">
<input name="txt1" type="text" id="txt" disabled="disabled" value="<?php echo
$row[0];?>">
</td>
<td><input  name="txt2"  type="text"   id="txt2"value="<?php  echo $row[1];?>"></td>
<td><input  name="txt3"  type="text"   id="txt3"value="<?php  echo $row[2];?>"></td>
<td><input  name="txt4"  type="text"   id="txt4"value="<?php  echo $row[3];?>"></td>
<td><input  name="txt5"  type="text"   id="txt5"value="<?php  echo $row[4];?>"></td>
<td><input  name="txt6"  type="text"   id="txt6"value="<?php  echo $row[5];?>"></td>
<td><input  name="txt7"  type="text"   id="txt7"value="<?php  echo $row[6];?>"></td>
<td><input  name="txt8"  type="text"   id="txt8"value="<?php  echo $row[7];?>"></td>
<td><input type="submit"name="btn1" value="SUBMIT">
</tr>
<?php
}
}
else
{
echo "no record found";
}
?>
