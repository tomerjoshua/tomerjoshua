<html>
<head>
</head>
<body>
<center>
<form name="frmreverse" method="post" action="reverseaction.php">
<table width="400" border="1" cellpadding="5" cellspacing="10">
<tr>
<td align="center">Enter the Number</td>
<td align="center"><input type="text" name="txt1"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="btn1" value="Submit"></td>
<td align="center"><input type="reset" name="btn2" value="Cancel"></td>
</tr>
</table>
</form>
</center>
</body>
</html>
