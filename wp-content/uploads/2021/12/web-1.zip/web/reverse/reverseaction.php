<?php
$n=$_POST['txt1'];
$p=$n;
$rev=0;
if($_POST['btn1'])
{
while($n!=0)
{
$r=$n%10;
$rev=$rev*10+$r;
$n=(int)($n/10);
}
echo "The reverse of ",$p," is ",$rev;
}
?>
