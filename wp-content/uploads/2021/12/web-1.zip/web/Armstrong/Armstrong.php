<html>
<head>
</head>
<body>
<center>
<form name="frmarmstrong" method="post" action="armstrongaction.php">
<h2><u>Check  whether  the  given   number  is Armstrong</u></h2>
<table  width="400"   border="1" cellpadding="10"cellspacing="5">
<tr>
<td align="center">Enter the number</td>
<td align="center"><input type="text"name="txt1"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="btn1" value="Submit"></td>
<td align="center"><input type="reset" name="btn2" value="Cancel"></td>
</tr>
</table>
</form>
</center>
</body>
</html>