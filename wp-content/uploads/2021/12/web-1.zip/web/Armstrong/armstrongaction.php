<?php
$n=$_POST['txt1'];
$a=$n;
$sum=0;
if($_POST['btn1'])
{
while($n>0)
{
$temp=$n%10;
$sum=$sum+$temp*$temp*$temp;
$n=$n/10;
}
if($a==$sum)
echo $a," is armstrong";
else
echo " not armstrong";
}
?>
 
