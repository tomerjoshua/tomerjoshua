<html>
<head>
</head>
<body>
<center>
<h2><u>Largest of three numbers</u></h2>
<form  name="frmgreat"  method="post"action="greataction.php">
<table width="400"border="1"cellpadding="10"cellspacing="5">
<tr>
<td align="center">First Number</td>
<td align="center"><input type="text"name="txt1"></td>
</tr>
<tr>
<td align="center">Second Number</td>
<td align="center"><input type="text" name="txt2"></td>
</tr>
<tr>
<td align="center">Third Number</td>
<td align="center"><input type="text"name="txt3"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="btn1"value="submit"></td>
<td align="center"><input type="reset" name="btn2"value="cencel"></td>
</tr>
</table>
</form>
</center>
</body>
</html
