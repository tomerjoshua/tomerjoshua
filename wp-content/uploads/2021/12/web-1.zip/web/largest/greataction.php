<?php
$a=$_POST['txt1'];
$b=$_POST['txt2'];
$c=$_POST['txt3']; if($_POST['btn1'])
{
if($a>$b && $a>$c)
echo "largest number is ",$a; else if($a<$b && $b>$c) echo "largest number is ",$b; else
echo "largest number is ",$c;
}
?>
