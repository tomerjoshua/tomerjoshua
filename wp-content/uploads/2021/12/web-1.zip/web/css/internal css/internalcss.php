<html>
<head>
 <style>
 body
 {
 background-color: blue;
 }
 h1
 {
 color: red; padding: 60px;
}
 </style>
</head>
<body><center>
 <h1>STAS, PULLARIKKUNNU</h1>
 <p>Hello all, Welcome to STAS</p></center>
</body>
 </html>