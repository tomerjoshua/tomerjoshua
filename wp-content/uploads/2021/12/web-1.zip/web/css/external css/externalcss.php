<html>
<head>
 <link rel="stylesheet" type="text/css" href="mystyle.css"> <h1>STAS</h1>
 <p>Welcome to STAS</p> </head>
 </html