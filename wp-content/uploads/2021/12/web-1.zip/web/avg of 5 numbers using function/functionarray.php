<html>
<head>
<title>Passing array to functions
</title>
</head>
<body>
<?php
$scores=array(65,83,78,90,98); averager($scores);

function averager($array)
{
$total=0;
$c=count($array); for($i=0;$i<$c;$i++)
{
$total=$total+$array[$i];
}
echo "Average=",$total/$c;
}


?>
</body>
</html>
