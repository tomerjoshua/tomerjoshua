<html>
<head>
</head>
<body>
<center>
<form name="frmgrade" method="post"action="gradeaction.php">
<h2><u>Student Marklist<u></h2>
<table width="400" border="1" cellpadding="10" cellspacing="5">
<tr>
<td>Roll Number</td>
<td><input type="text" name="txt1"></td>
</tr>
<tr>
<td>Name</td>
<td><input type="text" name="txt2"></td>
</tr>
<tr>
<td>Subject I</td>
<td><input type="text" name="txt3"></td>
</tr>
<tr>
<td>Subject II</td>
<td><input type="text" name="txt4"></td>
</tr>
<tr>
<td>Subject III</td>
<td><input type="text" name="txt5"></td>
</tr>
<tr>
<td><input type="submit" name="btn1" value="Submit"></td>
<td><input type="reset" name="btn2" value="Cancel"></td>
</tr>
</table>
</form>
</center>
</body>
</html>
