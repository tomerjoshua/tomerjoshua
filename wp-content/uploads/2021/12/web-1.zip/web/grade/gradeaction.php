<?php
$name=$_POST['txt2'];;
$roll=$_POST['txt1'];
$m1=$_POST['txt3'];
$m2=$_POST['txt4'];
$m3=$_POST['txt5'];
$t=0;
$p=0.0;
if($_POST['btn1'])
{
$t=$m1+$m2+$m3;
$p=$t/3; if($p>90)
$g="A+";
else if($p<=90 && $p>80)
$g='A';
else if($p<=80 && $p>70)
$g='B';
else if($p<=70 && $p>60)
$g='C';
else if($p<=60 && $p>50)
$g='D';
else
$g='E';
?>
 
<center>
<h2><u>Mark List</u></h2>
<table width="400" border="0" cellpadding="10" cellspacing="5">
<tr><td><?php echo "Register Number : "?></td><td><?php echo $roll?></td></tr>
<tr><td><?php echo "Name : "?></td><td><?php echo $name?></td></tr>
<tr><td><?php  echo  "Subject  I : "?></td><td><?php  echo $m1?></td></tr>
<tr><td><?php  echo  "Subject  II: "?></td><td><?php  echo $m2?></td></tr>
<tr><td><?php echo "Subject: "?></td><td><?php echo $m3?></td></tr>
<tr><td><?php echo "Total : "?></td><td><?php echo $t?></td></tr>
<tr><td><?php echo "Percentage : "?></td><td><?php echo $p?></td></tr>
<tr><td><?php echo "Grade : "?></td><td><?php echo $g?></td></tr>
</table>
</center>
<?php
}
?>
