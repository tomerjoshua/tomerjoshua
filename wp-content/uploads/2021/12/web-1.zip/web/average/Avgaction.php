<?php
$n=$_POST['txt1'];
$sum=0;
$avg=0.0;
if($_POST['btn1'])
{
for($i=1;$i<=$n;$i++)
{
$sum=$sum+$i;
}
$avg=$sum/$n;
echo "Average=",$avg;
}
?>
