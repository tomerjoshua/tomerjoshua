<?php date_default_timezone_set("Asia/Kolkata");
setcookie('LastDate',date("m/d/y H:i:s "),time()+(30*24*60*60*3600));
if(isset($_COOKIE['LastDate']))
{
$cookieVar=$_COOKIE['LastDate']; echo "Your last visit was $cookieVar";
}
else
echo "Welcome to this site";
?>
